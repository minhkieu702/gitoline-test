export const Players = [
    {
        id:1, 
        name: 'Kante', 
        club: 'Chelsea', 
        img:'/images/kante.jpg'},
    {
        id:2, 
        name: 'Ronaldo', 
        club: 'MU', 
        img:'/images/cr.jpg'},
    {
        id:3, 
        name: 'Messi', 
        club: 'PSG', 
        img:'/images/messi.jpg'},
    {
        id:4, 
        name: 'Mbappe', 
        club: 'PSG', 
        img:'/images/m.jpg'},
    {
        id:5, 
        name: 'Kane', 
        club: 'Totteham', 
        img:'/images/kane.jpg'},
        {
            id:6,
name:"Haaland",
img:'/images/haaland.jpg'
        },
];
